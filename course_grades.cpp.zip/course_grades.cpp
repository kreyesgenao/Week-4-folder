// This program collects five course IDs and grades,
// calculates the average, and assigns a letter grade.

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
    const int NUMBER_OF_COURSES = 5;

    string courseIDs[NUMBER_OF_COURSES];
    double grades[NUMBER_OF_COURSES];
    double total = 0.0;
    double average;
    string letterGrade;

    // Explain what the user needs to enter.
    cout << "COURSE GRADES AND AVERAGE\n";
    cout << "-------------------------\n";
    cout << "This program calculates your average for five courses.\n";
    cout << "Enter each course ID, such as CSC-115 or MAT-110.\n";
    cout << "After each course ID, enter its grade from 0 to 100.\n";
    cout << "Press Enter after each entry.\n";
    cout << "After all five courses, the program will display\n";
    cout << "your courses, grades, average, and final letter grade.\n";

    // Collect the five course IDs and grades.
    for (int i = 0; i < NUMBER_OF_COURSES; i++)
    {
        cout << "\nEnter course " << i + 1 << " ID: ";
        cin >> courseIDs[i];

        cout << "Enter the grade for " << courseIDs[i]
             << " (0-100): ";
        cin >> grades[i];

        // Check that the grade is a number from 0 to 100.
        if (!cin || grades[i] < 0 || grades[i] > 100)
        {
            cout << "\nInvalid grade. Please run the program again\n";
            cout << "and enter a number from 0 to 100.\n";
            return 1;
        }

        total += grades[i];
    }

    // Calculate the average.
    average = total / NUMBER_OF_COURSES;

    // Determine the letter grade using the syllabus scale.
    if (average >= 94)
        letterGrade = "A";
    else if (average >= 90)
        letterGrade = "A-";
    else if (average >= 86)
        letterGrade = "B+";
    else if (average >= 83)
        letterGrade = "B";
    else if (average >= 79)
        letterGrade = "B-";
    else if (average >= 75)
        letterGrade = "C+";
    else if (average >= 70)
        letterGrade = "C";
    else if (average >= 66)
        letterGrade = "C-";
    else if (average >= 64)
        letterGrade = "Not specified in syllabus";
    else
        letterGrade = "F";

    // Display all grades with two decimal places.
    cout << fixed << setprecision(2);
    cout << "\nCOURSE GRADES\n";
    cout << "-------------\n";

    for (int i = 0; i < NUMBER_OF_COURSES; i++)
    {
        cout << courseIDs[i] << ": " << grades[i] << endl;
    }

    // Display the final results.
    cout << "\nAverage Grade: " << average << endl;
    cout << "Letter Grade: " << letterGrade << endl;

    return 0;
}